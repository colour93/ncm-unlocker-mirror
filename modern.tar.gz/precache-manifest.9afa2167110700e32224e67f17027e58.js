self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e59892f6c2f0ad6ebd2d",
    "url": "css/app.30b45c25.css"
  },
  {
    "revision": "75769016c72999e604b0",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "640a6f9fe5a829b87e11c7ded53ff504",
    "url": "index.html"
  },
  {
    "revision": "2d12777f2703612307ff4a12f1b21899",
    "url": "ixarea-stats.js"
  },
  {
    "revision": "da19fcc36bad3622ecef4518cbc32f08",
    "url": "js/0.c9123a50.worker.js"
  },
  {
    "revision": "e59892f6c2f0ad6ebd2d",
    "url": "js/app.ff02a91c.js"
  },
  {
    "revision": "75769016c72999e604b0",
    "url": "js/chunk-vendors.a655fa4c.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);